# GENE.jax

## Todo

- [x] vmap all (evaluate model)
- [x] add biases
- [x] check flax (insert w&b into struct) (less integration problems) (cnn direct -> nn gene)
- [ ] test suite for gene encoding
    - [x] direct encoding
    - [ ] gene encoding
- [x] add direct encoding
- [x] implemment (working) evosax loop
- [x] test loop with direct enc
- [x] compare direct and indirect encoding (Cartpole) ~ 10 gen
- [x] notebook to present differences and results
- [x] Test suite rework
- [x] Example folder rework and cleaning


## Profiles
To utilize the json profile files, open them using the [scalene-gui app](https://plasma-umass.org/scalene-gui/).