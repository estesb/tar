# GENE.jax

## Profiling
To utilize the json profile files, open them using the [scalene-gui app](https://plasma-umass.org/scalene-gui/).