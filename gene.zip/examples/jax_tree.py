import jax.numpy as jnp
import jax.random as jrd
from jax import vmap, jit
from jax.tree_util import register_pytree_node_class
from functools import partial


@register_pytree_node_class
class Exp:
    def __init__(self) -> None:
        pass

    @partial(jit, static_argnums=(0))
    def apply(self, x):
        return jnp.exp(x)

    def tree_flatten(self):
        children = ()
        aux_data = {}
        return (children, aux_data)

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        return cls(*children)


@register_pytree_node_class
class F:
    """This definition of the class, makes it reactive to internal change.
    If self.operator is modified, the class is recompiled using the correct new function
    """

    def __init__(self, op) -> None:
        self.operator = op

    @jit
    def apply(self, *args):
        return self.operator(args)

    def tree_flatten(self):
        children = ()  # arrays / dynamic values
        aux_data = {"operator": self.operator}  # static values
        return (children, aux_data)

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        return cls(aux_data["operator"])


@jit
def run(state):
    return state["op"].apply(state["val"])


if __name__ == "__main__":
    state = {"op": Exp(), "val": jnp.arange(0, 10)}

    state_2 = {"op": F(jnp.log), "val": jnp.arange(0, 10)}

    ret = run(state)
    ret_2 = run(state_2)

    print(ret)
    print(ret_2)
