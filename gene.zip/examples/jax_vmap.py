import jax.numpy as jnp
from jax import vmap
import chex


a = jnp.array([[1, 3], [23, -5]])
b = jnp.array([[11, 7], [19, 13]])

res = jnp.add(a, b).T


chex.assert_trees_all_close(
    vmap(jnp.add, in_axes=(0, 0), out_axes=1)(a, b), jnp.add(a, b).T
)

res = jnp.add(a, b).T

print(res)
