import wandb
import jax.numpy as jnp
import math

wandb.init(project="halfcheetah training with brax&jax", config={"range": 100})


for i in jnp.arange(0, 100):
    xs = [i]
    ys = [[i], [jnp.log(i)]]
    wandb.log(
        {
            "line-series-plot1": wandb.plot.line_series(
                xs=xs,
                ys=ys,
                keys=["metric i", "metric log(i)"],
                title="i and log(i)",
                xname="step",
            )
        }
    )

    # wandb.log({"i": i, "log-value": jnp.log(i)})
