from gene.core.distances import get_df
from gene.learning import learn_brax_task
from gene.utils import fail_if_not_device, validate_json


if __name__ == "__main__":
    fail_if_not_device()
    config = {
        "seed": 0,
        "evo": {
            "strategy_name": "Sep_CMA_ES",
            "n_generations": 10,
            "population_size": 20,
            "n_evaluations": 1,
        },
        "net": {"layer_dimensions": [18, 64, 64, 6], "architecture": "bounded_linear"},
        "encoding": {"d": 3, "distance": "pL2", "type": "gene"},
        "task": {
            "environnment": "halfcheetah",
            "maximize": True,
            "episode_length": 500,
        },
        # "task": {"environnment": "walker2d", "maximize": True, "episode_length": 500},
    }
    validate_json(config)

    tracker, ts = learn_brax_task(config, get_df(config)(), None)

    print(ts["training"]["top_k_fit"])
