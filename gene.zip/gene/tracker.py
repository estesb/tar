class Tracker:
    def __init__(self) -> None:
        raise NotImplementedError
