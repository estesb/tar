# from jax import default_backend

# assert default_backend() == "gpu"
