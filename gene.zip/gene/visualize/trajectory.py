"""
Perform PCA on the genomes movement in high-dimensional space
and visualize the path taken in 3D.
"""
